package test.view;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public interface IChatView {

	public void addNeighbour(String name);
	
	public void messageArrived(String expeditor, String message);

	public void QueryArrived(String expeditor, String initiator, Integer id,
			String request, Integer ttl);

	public void msg(String string);

	public ArrayList<String> getNeighbours();
	
	public void setID(Integer newid);

	public void SearchNewNeighbours();
	
	public void addConnu(List<String> voisinsConnus);
	
	
}
