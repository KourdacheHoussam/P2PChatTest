/**
 * null
 * null
 * 
 * 
 * 
 * 
 * null
 * null
 * null
 * null
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * null
 * null
 **/
package test;


/**
 **/
public interface QueryvoisinsListener {
   //
   // Methods 
   //

   /**
    * SendQueryVoisins
    * null
    * @param ev a <code>QueryvoisinsEvent</code> value : event
    **/
   public  void SendQueryVoisins(QueryvoisinsEvent ev);


}
