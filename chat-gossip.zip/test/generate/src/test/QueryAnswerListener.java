/**
 * null
 * null
 **/
package test;


/**
 **/
public interface QueryAnswerListener {
   //
   // Methods 
   //

   /**
    * sendQueryAnswer
    * null
    * @param ev a <code>QueryAnswerEvent</code> value : event
    **/
   public  void sendQueryAnswer(QueryAnswerEvent ev);


}
