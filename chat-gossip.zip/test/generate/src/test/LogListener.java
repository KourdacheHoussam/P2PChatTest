/**
 * null
 * null
 * 
 * 
 * 
 * 
 * null
 * null
 * null
 * null
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 * 
 * 
 **/
package test;


/**
 **/
public interface LogListener {
   //
   // Methods 
   //

   /**
    * log
    * 
    * @param ev a <code>LogEvent</code> value : event
    **/
   public  void log(LogEvent ev);


}
