/**
 * null
 * null
 * 
 * 
 * 
 * 
 * null
 * null
 **/
package test;


/**
 **/
public interface QueryListener {
   //
   // Methods 
   //

   /**
    * sendQuery
    * null
    * @param ev a <code>QueryEvent</code> value : event
    **/
   public  void sendQuery(QueryEvent ev);


}
