/**
 * null
 * null
 * 
 * 
 * 
 * 
 * null
 * null
 * null
 * null
 * 
 * 
 * null
 * null
 **/
package test;


/**
 **/
public interface ChatListener {
   //
   // Methods 
   //

   /**
    * output
    * null
    * @param ev a <code>ChatEvent</code> value : event
    **/
   public  void output(ChatEvent ev);


}
