/**
 * null
 * null
 * 
 * 
 * 
 * 
 * null
 * null
 * null
 * null
 * 
 * 
 * null
 * null
 * 
 * 
 * 
 * 
 **/
package test;


/**
 **/
public interface InitDataListener {
   //
   // Methods 
   //

   /**
    * initData
    * 
    * @param ev a <code>InitDataEvent</code> value : event
    **/
   public  void initData(InitDataEvent ev);


}
