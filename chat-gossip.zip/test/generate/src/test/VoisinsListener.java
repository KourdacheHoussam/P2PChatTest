/**
 * null
 * null
 * 
 * 
 * 
 * 
 * null
 * null
 * null
 * null
 **/
package test;


/**
 **/
public interface VoisinsListener {
   //
   // Methods 
   //

   /**
    * sendVoisins
    * null
    * @param ev a <code>VoisinsEvent</code> value : event
    **/
   public  void sendVoisins(VoisinsEvent ev);


}
